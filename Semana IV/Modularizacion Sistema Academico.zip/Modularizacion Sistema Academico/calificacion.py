class Calificacion: #Clase Calificacion
    def __init__(self, materia, nota): #Constructor de la clase
        self.materia=materia
        self.nota=nota